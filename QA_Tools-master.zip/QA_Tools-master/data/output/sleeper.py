from lib.client.obra_client_base.client_response import ClientResponse


class Sleeper(ClientResponse):

    def __init__(self, with_JSON=None):
        """
        This is the class handles responses for Sleeper
        Any functionality needs to be added for this object has to be added here
        """

        self.timezone = None
        self.firstName = None
        self.lastName = None
        self.birthYear = None
        self.gender = None
        self.height = None
        self.goal = None
        self.zipcode = None
        self.birthMonth = None
        self.duration = None
        self.sleeperId = None
        self.login = None
        self.side = None
        self.isAccountOwner = None
        self.lastLogin = None
        self.licenseVersion = None
        self.privacyPolicyVersion = None
        self.firstSessionRecorded = None
        self.emailValidated = None
        self.active = None
        self.isChild = None
        self.weight = None

        args = ('timezone', 'firstName', 'lastName', 'birthYear', 'gender', 'height', 'goal', 'zipcode', 'birthMonth',
                'duration', 'sleeperId', 'login', 'side', 'isAccountOwner', 'lastLogin', 'licenseVersion',
                'privacyPolicyVersion', 'firstSessionRecorded', 'emailValidated', 'active', 'isChild', 'weight')
        super(Sleeper, self).__init__(instance_to_register=self, args=args,
                                      with_JSON=with_JSON)
