from lib.object_transformer.auto_property_mapper import AutoPropertyMapper


class Sleeper(AutoPropertyMapper):

    def __init__(self, with_JSON=None):
        """
        This is the class handles responses for Sleeper
        Any functionality needs to be added for this object has to be added here
        """

        # str Ex: US/Pacific
        timezone = None
        # str Ex: xilir
        firstName = None
        # str Ex: fiyeb
        lastName = None
        # str Ex: 1899
        birthYear = None
        # str Ex: M
        gender = None
        # NoneType Ex: None
        height = None
        # int Ex: 480
        goal = None
        # str Ex: 94085
        zipcode = None
        # int Ex: 12
        birthMonth = None
        # NoneType Ex: None
        duration = None
        # str Ex: -9223372036669857207
        sleeperId = None
        # str Ex: siq_automation.34541070@sleepnumber.com
        login = None
        # NoneType Ex: None
        side = None
        # bool Ex: True
        isAccountOwner = None
        # NoneType Ex: None
        lastLogin = None
        # str Ex: 0
        licenseVersion = None
        # str Ex: 0
        privacyPolicyVersion = None
        # NoneType Ex: None
        firstSessionRecorded = None
        # bool Ex: True
        emailValidated = None
        # bool Ex: True
        active = None
        # bool Ex: False
        isChild = None
        # NoneType Ex: None
        weight = None

        args = ('timezone', 'firstName', 'lastName', 'birthYear', 'gender', 'height', 'goal', 'zipcode', 'birthMonth',
                'duration', 'sleeperId', 'login', 'side', 'isAccountOwner', 'lastLogin', 'licenseVersion',
                'privacyPolicyVersion', 'firstSessionRecorded', 'emailValidated', 'active', 'isChild', 'weight')
        super(Sleeper, self).__init__(instance_to_register=self, args=args,
                                      with_JSON=with_JSON)
