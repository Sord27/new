from controllers.base_controller import BaseController
from lib.api.be.sleeper.request.be_get_sleepers_request import BeGetSleepersRequest
from lib.api.be.sleeper.request.be_unlink_from_cognito import BeUnlinkFromCognitoRequest
from lib.client.be_admin_client import BeAdminClient
from models.Sleeper import Sleeper


class BeSleeperController(BaseController):

    def __init__(self, be_client: BeAdminClient = None):
        super(BeSleeperController, self).__init__(be_client)


    @staticmethod
    def get_sleepers(be_client: BeAdminClient, access_token, account_id):
        return BeGetSleepersRequest(be_client).Call(account_id).sleeperList

