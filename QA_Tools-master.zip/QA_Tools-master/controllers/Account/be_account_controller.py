from controllers.base_controller import BaseController
from lib.api.be.sleeper.request.be_unlink_from_cognito import BeUnlinkFromCognitoRequest
from lib.api.be.user.response.be_get_filtered_users_response import BeGetFilteredUsersResponse
from controllers.Sleeper.be_sleeper_controller import BeSleeperController
from controllers.User.be_user_controller import BeUserController
from lib.api.be.account.request.be_account_accept_license_request import BeAccountAcceptLicenseRequest
from lib.api.be.account.request.be_account_create_request import BeAccountCreateRequest
from lib.api.be.account.request.be_account_delete_request import BeAccountDeleteRequest
from lib.api.be.account.request.be_set_password_and_activate_request import \
    BeSetPasswordAndActivateRequest
from lib.api.be.authenticate.request.be_authenticate_request import BeAuthenticateRequest
from lib.client.be_admin_client import BeAdminClient
from utilities.random_generator import RandomGenerateTools


class BeAccountController(BaseController):

    def __init__(self, be_client: BeAdminClient= None):
        super(BeAccountController, self).__init__(be_client)


    @staticmethod
    def create_account(be_client: BeAdminClient, first_name='', last_name='', login='', password='Password!123',
                       roles=None):
        def create_new_account(be_client: BeAdminClient, first_name, last_name, login, password):
            new_account = BeAccountController()
            if not first_name:
                first_name = RandomGenerateTools.generate_first_name()
            if not last_name:
                last_name = RandomGenerateTools.generate_last_name()
            if not login:
                login = RandomGenerateTools.generate_email()
            if not password:
                password = RandomGenerateTools.get_random_password_string(10)

            new_account.login = login
            new_account.password = password
            new_account.first_name = first_name
            new_account.last_name = last_name
            new_account.be_client = be_client

            if not be_client.auth_token:
                BeAuthenticateRequest(be_client).Call(
                    be_client._session.get_backoffice_username(),
                    be_client._session.get_backoffice_password())
            create_response = BeAccountCreateRequest(be_client).Call(first_name, last_name, login)
            set_password_response = BeSetPasswordAndActivateRequest(be_client).Call(password, login,
                                                                                    create_response.token)
            new_account.account_id = create_response.accountId

            BeAccountAcceptLicenseRequest(be_client).Call(login, password)
            return new_account

        new_account = create_new_account(be_client, first_name, last_name, login, password)
        if roles: new_account.get_users()[0].update_user(roles=roles)
        return new_account

    def get_sleepers(self):
        self.sleepers = BeSleeperController.get_sleepers(self.be_client, self.account_id)
        return self.sleepers

    def get_users(self):
        self.users = BeUserController.get_users(self.be_client, self.account_id)
        return self.users

    def delete_account(self, account_id = None, by_filter = None, ignore_failure = False):
        try:
            if not self.be_client.auth_token:
                BeAuthenticateRequest(self.be_client).Call(
                    self.be_client._session.get_backoffice_username(),
                    self.be_client._session.get_backoffice_password())
            if by_filter:
                account_id = BeUserController.get_users_by_filter(be_client= self.be_client, filter=by_filter).results[0].accountId

                try:
                    sleeper_controller = BeSleeperController()
                    sleeper_id = sleeper_controller.get_sleepers(self.be_client,self.be_client.auth_token, account_id)[0].sleeperId
                    BeUnlinkFromCognitoRequest(self.be_client).Call(account_id, sleeper_id)
                except:
                    pass
                delete_response = BeAccountDeleteRequest(self.be_client).Call((account_id or account_id))
                return delete_response

        except Exception as e:
            if not ignore_failure:
                raise e