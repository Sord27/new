from lib.api.be.user.response.be_get_filtered_users_response import BeGetFilteredUsersResponse
from lib.api.be.user.request.be_get_filtered_users_request import BeGetFilteredUsersRequest
from lib.api.be.user.request.be_get_users_request import BeGetUsersRequest
from lib.api.be.user.request.be_user_update_request import BeUserUpdateRequest
from lib.client.be_admin_client import BeAdminClient
from models.User import User


class BeUserController:

    def __init__(self, be_client: BeAdminClient, data: User):
        self.be_client = be_client
        self.data = data

    @staticmethod
    def get_users(be_client: BeAdminClient, account_id, access_token=''):
        users = []
        get_user_response = BeGetUsersRequest(be_client).Call(account_id, access_token=access_token)
        for user in get_user_response.userList:
            fetched_user = user
            fetched_user.parentAccountId = account_id
            users.append(BeUserController(be_client, fetched_user))
        return users

    def update_user(self, firstName=None, lastName=None, password=None, active=None,
                    login=None, reference=None, roles=None, ret_code=200, access_token=None):
        BeUserUpdateRequest(self.be_client).Call(self.data.parentAccountId, self.data.userId, firstName=firstName,
                                                 lastName=lastName, password=password, active=active,
                                                 login=login, reference=reference, roles=roles, ret_code=ret_code,
                                                 access_token=access_token)

    @staticmethod
    def get_users_by_filter(be_client: BeAdminClient, filter, access_token='') -> BeGetFilteredUsersResponse:
        get_user_response = BeGetFilteredUsersRequest(be_client).Call(filter, access_token=access_token)
        return get_user_response