from lib.client.be_admin_client import BeAdminClient


class BaseController:

    def __init__(self, be_client: BeAdminClient= None):
        self.be_client = be_client
