import json
import requests
from lib.client.obra_client_base.obraclient import OBRAClient
from utilities.data_utilities import DataUtilities


class BaseRequest:
    def __init__(self, client: OBRAClient, url, data_folder='/api_data'):
        self._data_folder = data_folder
        if url and len(url) > 1 and url[0] != '/':
            url = "/" + url
        self._url = client.api + url
        self._client = client

    def get(self, parameters=None, headers=None, response_type=None, ret_code=200):
        response = requests.get(url=self._url, params=(parameters or {}),
                                headers=self.prepare_headers(headers), proxies=self._client.get_proxy(),
                                verify=self._client.get_verify_SSL())

        return self.deliver_response(response, response_type, ret_code)

    def put(self, body, parameters=None, headers=None, response_type=None, ret_code=200):

        response = requests.put(url=self._url, data=json.dumps(body), params=(parameters or {}),
                                headers=self.prepare_headers(headers), proxies=self._client.get_proxy(),
                                verify=self._client.get_verify_SSL())

        return self.deliver_response(response, response_type, ret_code)

    def post(self, body, parameters=None, headers=None, response_type=None, ret_code=200):
        response = requests.post(url=self._url, data=json.dumps(body), params=(parameters or {}),
                                 headers=self.prepare_headers(headers), proxies=self._client.get_proxy(),
                                 verify=self._client.get_verify_SSL())

        return self.deliver_response(response, response_type, ret_code)

    def delete(self, body, parameters=None, headers=None, response_type=None, ret_code=200):
        response = requests.delete(url=self._url, data=json.dumps(body), params=(parameters or {}),
                                   headers=self.prepare_headers(headers), proxies=self._client.get_proxy(),
                                   verify=self._client.get_verify_SSL())

        return self.deliver_response(response, response_type, ret_code)

    def prepate_params(self, access_token):
        access_token = (access_token or self._client.auth_token)
        params = {'access_token': access_token}
        return params

    def deliver_response(self, response, response_type, ret_code):
        if response.status_code == ret_code:
            try:
                if response_type == None:
                    return response.text
            except Exception as e:
                raise Exception(f"API response different than expected type {e}: {response.text}")
            return response_type.parse_raw(response.text)
        else:
            print("URL: " + self._url)
            # print("Request: ")todo
            # print(response.raw_request)
            print("Response: ")
            print(response.text)
            raise Exception(f"API call error on {self._url} Expected: {ret_code}. Received: {response.status_code}")

    def prepare_headers(self, headers=None):
        headers = (headers or {})
        client_headers = self._client.headers.copy()
        client_headers.update(headers)
        return client_headers

    def read_json_from_data_folder(self, file_name):
        return DataUtilities.read_json_from_data_folder(f'{self._data_folder}/{file_name}')

    def set_account_id_to_url(self, account_id):
        self._url = self._url.replace('{{account_id}}', account_id)

    def set_user_id_to_url(self, user_id):
        self._url = self._url.replace('{{user_id}}', user_id)

    def set_sleeper_id_to_url(self, sleeper_id):
        self._url = self._url.replace('{{sleeper_id}}', sleeper_id)
