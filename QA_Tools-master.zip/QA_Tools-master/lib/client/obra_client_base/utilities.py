import logging
import re
import urllib
import urllib.parse


def query_string(url: str, d: dict, is_sorted: bool = True) -> str:
    """
    Takes a url and a dictionary of key-value arguments that will be used
    to create a url query string. Creates the fully functional url.
    :param url:
    :param d:
    :param is_sorted:
    :return:
    """
    args = dict_to_args(d)
    keys = sorted(args) if is_sorted else list(args.keys())
    return url + "?" + "&".join([key + "=" + args[key] for key in keys])


def query_string_unsorted(url: str, d: dict) -> str:
    """
    Takes a url and a dictionary of key-value arguments that will be used
    to create a url query string. Creates the fully functional url.
    :param url:
    :param d:
    :return:
    """
    return query_string(url, d, False)


def parse_query(q: str, is_sorted: bool = True) -> (str, dict):
    """
    Parses a query string that is supposedly consists of a url and key-value
    argument pairs. Parsing returns a tuple of a string (url part) and a dictionary
    (key-value parameters) object.
    :param q:
    :param is_sorted:
    :return:
    """
    url = ""
    try:
        url = q[:q.index("?")]
        q = q[q.index("?"):]
    except Exception:
        pass

    if q.startswith("?"):
        q = q[1:]

    try:
        q = q.strip()
    except Exception:
        pass

    if q == "":
        return url, {}

    try:
        arr = [pair.split("=") for pair in q.split("&")]
    except Exception:
        return url, {}
    args = {}
    for k, v in arr:
        args[k] = v

    new_dict = {}
    try:
        new_dict = args_to_dict(args, is_sorted)
    except Exception as e:
        logging.error("Error happened in the url parser4 - " + str(e) + " - " + url + " - " + q)

    return url, new_dict


def parse_query_unsorted(q: str) -> (str, dict):
    """
    Parses a query string that is supposedly consists of a url and key-value
    argument pairs. Parsing returns a tuple of a string (url part) and a dictionary
    (key-value parameters) object.
    :param q:
    :return:
    """
    return parse_query(q, False)


def param_quote(value: str) -> str:
    """
    Quotes the + (plus) sign inside a url.
    :param value:
    :return:
    """
    return urllib.parse.quote_plus(value)


def param_unquote(value: str) -> str:
    """
    Uquotes the + (plus) sign inside a url.
    :param value:
    :return:
    """
    return urllib.parse.unquote_plus(value)


def type_cast(value) -> object:
    """
    Tries to type cast a byte, string or SupportsInt object to int object
    Returns the parameter object if it fails to type cast.
    :param value:
    :return:
    """
    try:
        if type(value) is str:
            return int(value.replace("_", "-"))
        else:
            return int(value)
    except ValueError:
        return value


def dot_escape(s: str) -> str:
    """Excapes a dot character inside a string"""
    return s.replace(".", "..")


def list_to_args(l: list) -> dict:
    """
    Takes a list of parameters and creates a argument dictionary using them.
    :param l:
    :return:
    """
    args = {}
    pos = 0
    for i in l:
        if type(i) == dict:
            sub = dict_to_args(i)
            for s, nv in sub.items():
                args[str(pos) + "." + s] = nv
        elif type(i) == list:
            sub = list_to_args(i)
            for s, nv in sub.items():
                args[str(pos) + "." + s] = nv
        else:
            args[str(pos)] = param_quote(str(i))
        pos += 1
    return args


def dict_to_args(d: dict) -> dict:
    """
    Takes a dictionary of arguments and creates a argument dictionary from them.
    :param d:
    :return:
    """
    args = {}
    for k, v in d.items():
        if type(v) == dict:
            sub = dict_to_args(v)
            for s, nv in sub.items():
                args[param_quote(dot_escape(k)) + "." + s] = nv
        elif type(v) == list:
            sub = list_to_args(v)
            for s, nv in sub.items():
                args[param_quote(dot_escape(k)) + "." + s] = nv
        else:
            args[param_quote(dot_escape(k))] = param_quote(str(v))
    return args


def dot_split(s: str) -> list:
    """Splits a str object using the dot character as the splitter."""
    return [param_unquote(part).replace("..", ".") for part in re.split("(?<!\.)\.(?!\.)", s)]


def args_to_dict(args: dict, is_sorted: bool = False) -> dict:
    """
    Takes a dictionary of url arguments and creates a python compatible dictionary object from them.
    :param args:
    :param is_sorted:
    :return:
    """
    d = {}
    keys = sorted(args) if is_sorted else list(args.keys())

    for arg in keys:
        value = args[arg]

        # bits = arg.split(".")
        bits = dot_split(arg)
        ctx = d

        for i in range(len(bits)):
            bit = bits[i]
            last = not (i < len(bits) - 1)

            next_is_dict = False
            if not last:
                try:
                    int(bits[i + 1])
                except ValueError:
                    next_is_dict = True

            if type(ctx) == dict:
                if bit not in ctx:
                    if not last:
                        ctx[bit] = {} if next_is_dict else []
                        ctx = ctx[bit]
                    else:
                        ctx[bit] = type_cast(param_unquote(value))
                        ctx = None
                else:
                    ctx = ctx[bit]
            elif type(ctx) == list:
                if not last:
                    if int(bit) > len(ctx) - 1:
                        ctx.append({} if next_is_dict else [])
                    # ctx.append({} if next_is_dict else [])
                    ctx = ctx[int(bit)]
                else:
                    ctx.append(type_cast(param_unquote(value)))
                    ctx = None
    return d
