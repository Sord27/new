"""
Basic response class.
This class can be used to create endpoint response object.
Fundamentally it has status and message fields that every response
from any REST-Api endpoint should send.
This class inherits the AutoPropertyMapper class, so that every child of this
class can be directly returned as python object representation of endpoint request
responses.
"""

import requests
from pydantic.main import BaseModel


class ClientResponse(BaseModel):
    JSON_PROPERTY_MAP = ('status', 'message', 'raw_response', 'raw_request', "success", "error_code", "result")

    def __init__(self, instance_to_register=None, args=None, with_JSON=None) -> None:
        """
        Initializes both this class and the super class AutoPropertyMapper
        Class has two JSON key value parameters, status and message.
        :param instance_to_register:
        :param args:
        :param with_JSON:
        """
        if instance_to_register is None:
            instance_to_register = self
        if args is None:
            args = {}
        self.instance = instance_to_register
        self.http_response = None
        self.raw_request = None
        self.raw_response = None
        self.success = True
        self.error_code = 0
        self.result = None
        self.message = ""
        self.http_response = None
