import json

import requests as req
from requests import PreparedRequest, Response
from lib.client.obra_client_base import content_type
from lib.client.obra_client_base.client_response import ClientResponse
from lib.client.obra_client_base.request import Request
from lib.obra_session import OBRASession


class OBRAClient(object):

    def __init__(self, api, session: OBRASession):
        """Initialisation point of the class.
        This class has two fields: SSL Verification status and a proxy."""
        super(OBRAClient, self).__init__()
        self._verifySSL = True
        self._proxy = None
        self._session = session
        self.auth_token = None
        self.api = api
        self.headers = {
            "Connection": "Keep-live",
            "Content-Type": content_type.APPLICATION_JSON,
            "Accept": "*/*",
            "Accept-Language": "en-us"
        }

    def set_verify_SSL(self, state: bool) -> None:
        """Sets verify SSL status."""
        self._verifySSL = state

    def get_verify_SSL(self) -> bool:
        """Gets SSL verify status."""
        return self._verifySSL

    def set_proxy(self, proxy: str) -> None:
        self._proxy = {"http": "http://" + proxy, "https": "https://" + proxy}
        self.set_verify_SSL(False)

    def get_proxy(self) -> dict:
        """Gets currently set proxy configuration as dictionary object."""
        return self._proxy

    def api(self, prepped_request: PreparedRequest) -> Response:
        """Sets client specific headers that all the requests must have
        then according to the configurations sends the prepared request.
        """
        prepped_request.headers["Connection"] = "Keep-live"
        prepped_request.headers["Content-Type"] = content_type.APPLICATION_JSON
        prepped_request.headers["Accept"] = "*/*"
        prepped_request.headers["Accept-Language"] = "en-us"
        s = req.Session()

        return s.send(prepped_request)

    def map_server_response(self, response_class, raw_response, http_response, raw_request):
        """
        When the structure of the endpoint response is specifically known this method is used
        to create python object representation of the endpoint response JSON object.
        response_class supposed to be an instance from any child of response.Response class.
        :param response_class:
        :param raw_response:
        :param http_response:
        :param raw_request
        :return:
        """
        http_status_code = 0

        if http_response.status_code is not None:
            http_status_code = http_response.status_code
        if response_class == None:
            response_class = ClientResponse
        try:
            json_response = json.loads(raw_response)
            response_object = response_class(json_response)
        except Exception as exc:
            response_object = response_class()
        response_object.status_code = http_response.status_code
        response_object.set_http_response(http_response)
        response_object.set_raw_response(raw_response)
        response_object.set_raw_request(raw_request)

        return response_object

    def request(self, path: str) -> Request:
        """Creates a client specific request and send the reference to this object."""
        return Request(self, self.api + path)
