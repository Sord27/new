import json

import brotli
import requests as req
from lib.client.obra_client_base import method_type
from lib.client.obra_client_base.client_response import ClientResponse
from lib.client.obra_client_base.utilities import query_string_unsorted


class Request(object):

    def __init__(self, client, _url) -> None:
        super(Request, self).__init__()
        """
        Initialization of the Request class.
        This class has url, url parameters, http request method, post body key-values, a body,
        headers dictionary fields as the helper to build a http request.
        """
        self._client = client
        self._method = method_type.GET
        self._url = _url
        self._params = None
        self._posts = None
        self._forms = None
        self._body = None
        self._headers = None
        self._default_headers = True
        self._http_response = None
        self._strip_body = False

    def set_method(self, method):
        """Sets HTTP request method"""
        self._method = method
        return self

    def set_strip(self, _strip_body: bool):
        """Sets HTTP request method"""
        self._strip_body = _strip_body
        return self

    def get_method(self):
        """Gets HTTP request method"""
        return self._method

    def add_param(self, **kwargs):
        """Takes key-value pairs as the arguments and adds them to final url parameters dictionary"""
        if self._params is None:
            self._params = {}
        for key, value in kwargs.items():
            self._params[key] = value
        return self

    def add_json_body(self, **kwargs):
        """Takes key-value pairs as the arguments and adds them to final post body JSON"""
        if self._posts is None:
            self._posts = {}
        for key, value in kwargs.items():
            self._posts[key] = value
        return self

    def add_form(self, **kwargs):
        """Takes key-value pairs as the arguments and adds them to final post body JSON"""
        if self._forms is None:
            self._forms = {}
        for key, value in kwargs.items():
            self._forms[key] = value
        return self

    def add_header(self, **kwargs):
        """Takes key-value pairs as the arguments and adds them to final headers dictionary"""
        if self._headers is None:
            self._headers = {}
        for key, value in kwargs.items():
            self._headers[key] = value
        return self

    def add_file(self):
        """This is left as a draft for further implementations"""
        return self

    def _add_default_headers(self):
        """This is left as a draft for further implementations"""
        return self

    def set_add_default_headers(self, default_headers):
        """Sets the bool value for the class to decide whether to add default headers."""
        self._default_headers = default_headers
        return self

    def set_body(self, body):
        """Sets the special body for the request."""
        self._body = body
        return self

    def set_access_token(self, access_token):
        """Sets if request requires authentication."""
        if not self._params:
            self._params = {}

        self._params['access_token'] = access_token
        return self

    def _build_http_request(self):
        """
        Builds the request to be send using the final values of each component.
        :return:
        """
        endpoint = self._url
        if bool(self._posts):
            data_to_send = json.dumps(self._posts)
            if self._strip_body:
                data_to_send = "".join(data_to_send.split())
        else:
            data_to_send = None

        if bool(self._forms):
            data_to_send = query_string_unsorted("", self._forms)[1:]

        if bool(self._params):
            request = req.Request(self._method, endpoint, headers=self._headers, data=data_to_send, params=self._params)
        else:
            request = req.Request(self._method, endpoint, headers=self._headers, data=data_to_send)
        return request.prepare()

    def get_raw_request(self):
        request_dict = {}
        request_dict.update({"method": self.get_method()})
        request_dict.update({"params": self._params})
        request_dict.update({"forms": self._forms})
        request_dict.update({"post_body": self._posts})
        request_dict.update({"headers": self._headers})
        request_dict.update({"url": self._url})
        request_dict.update({"body": self._body})
        return json.dumps(request_dict)

    def get_http_response(self):
        """Gets the resulting response of the built http request as the requests.Response object."""
        if self._http_response is None:
            self._http_response = self._client.api(self._build_http_request())

        return self._http_response

    def get_raw_response(self):
        """Gets the resulting response of the built http request as plain text."""
        if not self._http_response:
            self.get_http_response()
        key = 'Content-Encoding'
        if key in self._http_response.headers and self._http_response.headers['Content-Encoding'] == 'br':
            try:
                data = brotli.decompress(self._http_response.content)
                data1 = data.decode('utf-8')
                return data1
            except:
                pass
        return self._http_response.text

    def get_response(self, response_class=None) -> ClientResponse:
        """
        Gets the resulting response of the built http request as the python object that is a
        child of client.Response class.
        """
        try:
            self.get_http_response()
            return self._client.map_server_response(response_class, self.get_raw_response(),
                                                    self._http_response, self.get_raw_request())
        except Exception as e:
            print("API call exception: " + str(e))
            print("URL: " + self._url)
            print("Request: ")
            print(self.get_raw_request())
            raise Exception(f"API call error " + self._url)
