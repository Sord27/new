from lib.client.obra_client_base.obraclient import OBRAClient
from lib.obra_session import OBRASession


class BeAdminClient(OBRAClient):

    def __init__(self, session: OBRASession):
        super(BeAdminClient, self).__init__(session.environment.BE_ADMIN, session)
