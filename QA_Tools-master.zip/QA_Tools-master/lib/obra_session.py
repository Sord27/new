from entities.environments.environment_mapper import environment_mapper
from utilities.data_utilities import DataUtilities


class OBRASession:
    def __init__(self, environment_str: str):
        self.global_variables = {}
        self.environment = environment_mapper[environment_str.lower()]
        self.environment_str = environment_str
        self.secrets = DataUtilities.read_json_from_data_folder('/secret.json')

    def set_global_variable(self, key, value):
        self.global_variables[key] = value

    def get_global_variable(self, key):
        return self.global_variables[key]

    def read_secret(self, key):
        return self.secrets[key]
    
    def read_credential(self, environment, type):
        for credential in self.secrets['credentials']:
            if credential["environment"].lower() == environment.lower() and  credential["type"].upper() == type.upper():
                return credential
        raise Exception("Environment is not found")
            

    def get_backoffice_username(self):
        credentials = {}
        try:
            credentials = self.read_credential(self.environment_str, "backoffice")
        except:
            credentials = self.read_credential("default", "backoffice")

        return credentials['username']

    def get_backoffice_password(self):
        credentials = {}
        try:
            credentials = self.read_credential(self.environment_str, "backoffice")
        except:
            credentials = self.read_credential("default", "backoffice")
        return credentials['password']