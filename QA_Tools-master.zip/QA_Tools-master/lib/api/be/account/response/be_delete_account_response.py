from lib.client.obra_client_base.client_response import ClientResponse


class BeDeleteAccountResponse(ClientResponse):

    def __init__(self, with_JSON=None):
        """
        This is the class handles responses for BeDeleteAccountResponse
        Any functionality needs to be added for this object has to be added here
        """

        # str Ex: -9223372036670311716
        accountId = None

        args = ('accountId',)
        super(BeDeleteAccountResponse, self).__init__(instance_to_register=self, args=args,
                                                      with_JSON=with_JSON)
