from __future__ import annotations

from typing import Any, List

from pydantic import BaseModel


class ComponentItem(BaseModel):
    status: str
    reference: str
    version: str
    generation: str
    zipcode: str
    type: int
    code: str
    base: str
    installDate: Any
    installer: Any
    componentId: str
    serial: str
    sku: str
    purchaseDate: str
    chamber: int
    kidsbed: bool
    parentBedComponent: str
    orderNumberToExchange: Any
    bedsize: str


class Address(BaseModel):
    street1: str
    street2: str
    city: str
    state: str
    zipcode: str
    country: str
    phoneNumber: Any


class BePostAccountCreateResponse(BaseModel):
    component: List[ComponentItem]
    reference: str
    token: str
    address: Address
    loginHyperlink: str
    timezone: str
    email: str
    login: str
    firstName: str
    lastName: str
    community: str
    accountId: str
