from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class BeSetPostPasswordAndActivateResponse(BaseModel):
    passwordSetInCognito: Any
    login: str
