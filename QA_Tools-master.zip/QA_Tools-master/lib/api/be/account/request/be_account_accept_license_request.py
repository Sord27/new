from lib.client.be_admin_client import BeAdminClient
from lib.client.obra_client_base.base_request import BaseRequest

# noinspection PyMethodOverriding


class BeAccountAcceptLicenseRequest(BaseRequest):
    def __init__(self, client: BeAdminClient):
        url = '/bam/rest/sn/v1/account/acceptLicense'
        data_folder = '/api_data/account/accept_license'
        super(BeAccountAcceptLicenseRequest, self).__init__(client, url, data_folder)

    def Call(self, login='', password='RFv2Password!', license_number='5', ret_code=200, access_token=''):
        body = self.prepare_body(login, password, license_number)
        params = self.prepate_params(access_token)
        return super(BeAccountAcceptLicenseRequest, self).put(body=body, parameters=params, ret_code=ret_code,
                                                              response_type=None)

    def prepare_body(self, login='', password='', license_number='5'):
        json = {}
        json['login'] = login
        json['password'] = password
        json['licenseNumber'] = license_number
        return json
