from lib.api.be.account.response.be_set_post_password_and_activate_response import \
    BeSetPostPasswordAndActivateResponse
from lib.client.be_admin_client import BeAdminClient
from lib.client.obra_client_base.base_request import BaseRequest

# noinspection PyMethodOverriding
from utilities.random_generator import RandomGenerateTools


class BeSetPasswordAndActivateRequest(BaseRequest):
    def __init__(self, client: BeAdminClient):
        url = '/bam/rest/sn/v1/account/setPasswordAndActivate'
        data_folder = '/api_data/account/set_password_and_activate'
        super(BeSetPasswordAndActivateRequest, self).__init__(client, url, data_folder)

    def Call(self, password='RFv2Password!', login='', token='', reason='2', ret_code=200,
             access_token='') -> BeSetPostPasswordAndActivateResponse:
        body = self.prepare_body(login, token, password, reason)
        params = self.prepate_params(access_token)
        return super(BeSetPasswordAndActivateRequest, self).post(body=body, parameters=params, ret_code=ret_code,
                                                                 response_type=BeSetPostPasswordAndActivateResponse)

    def prepare_body(self, login='', token='', password='', reason='2'):
        json = self.read_json_from_data_folder('set_password_and_activate.json')
        if not password:
            password = RandomGenerateTools.get_random_password_string(10)

        json['login'] = login
        json['password'] = password
        json['token'] = token
        json['reason'] = reason
        return json
