from random import randint

from lib.api.be.account.response.be_post_account_create_response import BePostAccountCreateResponse
from lib.client.be_admin_client import BeAdminClient
from lib.client.obra_client_base.base_request import BaseRequest
# noinspection PyMethodOverriding
from utilities.random_generator import RandomGenerateTools


class BeAccountCreateRequest(BaseRequest):
    def __init__(self, client: BeAdminClient):
        url = '/bam/rest/sn/v1/account'
        data_folder = '/api_data/account'
        super(BeAccountCreateRequest, self).__init__(client, url, data_folder)

    def Call(self, first_name='', last_name='', email='', ret_code=201, access_token='') -> BePostAccountCreateResponse:

        body = self.prepare_body(first_name, last_name, email)
        params = self.prepate_params(access_token)

        return super(BeAccountCreateRequest, self).post(body=body, parameters=params, ret_code=ret_code,
                                                        response_type=BePostAccountCreateResponse)

    def prepare_body(self, first_name='', last_name='', email=''):
        json = self.read_json_from_data_folder('create_account.json')

        referance = str(randint(910000, 9910000))
        if not first_name:
            first_name = RandomGenerateTools.generate_first_name()
        if not last_name:
            last_name = RandomGenerateTools.generate_last_name()
        if not email:
            email = RandomGenerateTools.generate_email()

        json['firstName'] = first_name
        json['lastName'] = last_name
        json['login'] = email

        json['reference'] = f"rfv2_{referance}"
        i = 1
        for component in json['components']:
            component['reference'] = f"{referance}-{i}-AID"
            component['parentBedComponent'] = referance + "-1-AID-P"
            i += 1
        return json
