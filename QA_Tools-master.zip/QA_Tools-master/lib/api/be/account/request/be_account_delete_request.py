from lib.api.be.account.response.be_delete_account_response import BeDeleteAccountResponse
from lib.client.be_admin_client import BeAdminClient
from lib.client.obra_client_base.base_request import BaseRequest

# noinspection PyMethodOverriding


class BeAccountDeleteRequest(BaseRequest):
    def __init__(self, client: BeAdminClient):
        url = '/bam/rest/sn/v1/account/{{account_id}}'
        data_folder = '/api_data/account'
        super(BeAccountDeleteRequest, self).__init__(client, url, data_folder)

    def Call(self, account_id, ret_code=200, access_token='') -> BeDeleteAccountResponse:
        self.set_account_id_to_url(account_id)
        params = self.prepate_params(access_token)

        return super(BeAccountDeleteRequest, self).delete(body={}, parameters=params, ret_code=ret_code,
                                                          response_type=BeDeleteAccountResponse)
