from lib.api.be.authenticate.response.be_put_authenticate_response import BePutAuthenticateResponse
from lib.client.be_admin_client import BeAdminClient
from lib.client.obra_client_base.base_request import BaseRequest


# noinspection PyMethodOverriding
class BeAuthenticateRequest(BaseRequest):
    def __init__(self, client: BeAdminClient):
        url = '/bam/rest/sn/v1/authenticate'
        data_folder = '/api_data/authenticate/'
        super(BeAuthenticateRequest, self).__init__(client, url, data_folder)

    def Call(self, login, password, ret_code=200) -> BePutAuthenticateResponse:

        json = self.read_json_from_data_folder('authenticate_request_data.json')
        json['login'] = login
        json['password'] = password
        response = self.put(body=json, response_type=BePutAuthenticateResponse, ret_code=ret_code)
        try:
            auth = response.access_token
            self._client.auth_token = auth
        except:
            print('Login is not successful: ' + login)
            pass
        return response
