from __future__ import annotations

from typing import List

from pydantic import BaseModel


class BePutAuthenticateResponse(BaseModel):
    roles: List[str]
    sleeperId: str
    registrationState: int
    privacyPolicyAccepted: bool
    licenseAccepted: bool
    token_type: str
    access_token: str
