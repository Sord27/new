from lib.api.be.sleeper.response.be_get_sleepers_response import BeGetSleepersResponse
from lib.client.be_admin_client import BeAdminClient
from lib.client.obra_client_base.base_request import BaseRequest

# noinspection PyMethodOverriding


class BeUnlinkFromCognitoRequest(BaseRequest):
    def __init__(self, client: BeAdminClient):
        url = '/bam/rest/sn/v1/account/{{account_id}}/sleeper/{{sleeper_id}}/unlinkUserFromCognito'
        super(BeUnlinkFromCognitoRequest, self).__init__(client, url)

    def Call(self, account_id, sleeper_id, ret_code=200, access_token='') -> BeGetSleepersResponse:
        self.set_account_id_to_url(account_id)
        self.set_sleeper_id_to_url(sleeper_id)
        params = self.prepate_params(access_token)
        params["removeFromCognito"] = "false"

        return super(BeUnlinkFromCognitoRequest, self).put(parameters=params, ret_code=ret_code, body="")