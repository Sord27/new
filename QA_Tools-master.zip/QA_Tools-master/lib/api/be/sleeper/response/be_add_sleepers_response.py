from lib.client.obra_client_base.client_response import ClientResponse


class BeGetSleepersResponse(ClientResponse):

    def __init__(self, with_JSON=None):
        """
        This is the class handles responses for BeGetSleepersResponse
        Any functionality needs to be added for this object has to be added here
        """

        # list Ex: [{'timezone': 'US/Pacific', 'firstName': 'coxet', 'lastName': 'tupud', 'birthYear': '1899', 'gender': 'M', 'height': None, 'goal': 480, 'zipcode': '94085', 'birthMonth': 12, 'duration': None, 'sleeperId': '-9223372036669857209', 'login': 'siq_automation_23556369@sleepnumber.com', 'side': None, 'isAccountOwner': True, 'lastLogin': None, 'licenseVersion': '0', 'privacyPolicyVersion': '0', 'firstSessionRecorded': None, 'emailValidated': True, 'active': True, 'isChild': False, 'weight': None}]
        sleeperList = None

        args = ('sleeperList',)
        super(BeGetSleepersResponse, self).__init__(instance_to_register=self, args=args,
                                                    with_JSON=with_JSON)
