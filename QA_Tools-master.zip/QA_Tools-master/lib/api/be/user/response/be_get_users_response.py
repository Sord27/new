from __future__ import annotations

from typing import List

from pydantic import BaseModel
from models.User import User


class BeGetUsersResponse(BaseModel):
    userList: List[User]
