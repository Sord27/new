from lib.client.be_admin_client import BeAdminClient
from lib.client.obra_client_base.base_request import BaseRequest

# noinspection PyMethodOverriding


class BeUserUpdateRequest(BaseRequest):
    def __init__(self, client: BeAdminClient):
        url = '/bam/rest/sn/v1/account/{{account_id}}/user/{{user_id}}'
        super(BeUserUpdateRequest, self).__init__(client, url)

    def Call(self, accountId, userId, firstName=None, lastName=None, password=None, active=None,
             login=None, reference=None, roles=None, ret_code=200, access_token=None):
        self.set_user_id_to_url(userId)
        self.set_account_id_to_url(accountId)
        params = self.prepate_params(access_token)

        body = self.prepare_body(firstName=firstName, lastName=lastName, password=password, active=active,
                                 login=login, reference=reference, roles=roles)
        return super(BeUserUpdateRequest, self).put(body=body, parameters=params, ret_code=ret_code, response_type=None)

    def prepare_body(self, firstName=None, lastName=None, password=None, active=None,
                     login=None, reference=None, roles=None):
        json = {}
        if firstName:
            json['firstName'] = firstName
        if lastName:
            json['lastName'] = lastName
        if password:
            json['password'] = password
        if active:
            json['active'] = active
        if login:
            json['login'] = login
        if reference:
            json['reference'] = reference
        if roles:
            json['roles'] = roles
        if firstName:
            json['firstName'] = firstName
        return json
