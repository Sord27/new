from lib.api.be.user.response.be_get_filtered_users_response import BeGetFilteredUsersResponse
from lib.client.be_admin_client import BeAdminClient
from lib.client.obra_client_base.base_request import BaseRequest

# noinspection PyMethodOverriding


class BeGetFilteredUsersRequest(BaseRequest):
    def __init__(self, client: BeAdminClient):
        url = '/bam/rest/sn/v1/filteredUsers'
        super(BeGetFilteredUsersRequest, self).__init__(client, url)

    def Call(self, filterByString, ret_code=200, access_token='') -> BeGetFilteredUsersResponse:
        params = self.prepate_params(access_token)
        params["filterByString"]=filterByString
        return super(BeGetFilteredUsersRequest, self).get(parameters=params, ret_code=ret_code,
                                                  response_type=BeGetFilteredUsersResponse)
