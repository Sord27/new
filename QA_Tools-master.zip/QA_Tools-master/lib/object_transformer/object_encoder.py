from json import JSONEncoder

from singledispatch import singledispatch


@singledispatch
def transformer(obj):
    """ generic function to transform object before JSON encoding """

    return obj


@transformer.register(list)
@transformer.register(tuple)
@transformer.register(set)
def transformer_list(obj):
    """ transformer function implementation for the collection types listed above """
    return [transformer(item) for item in obj]


@transformer.register(dict)
def transformer_dict(obj):
    """ transformer function implementation for the collection types listed above """
    return dict((key, transformer(obj[key])) for key in obj)


class CustomObjectEncoder(JSONEncoder):
    """ :class:`JSONEncoder` delegating to transformer dispatched function """

    def default(self, obj):
        encoded = transformer(obj)
        if encoded is obj:
            return JSONEncoder.default(self, obj)
        return encoded
