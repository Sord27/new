from lib.object_transformer.object_encoder import transformer
from lib.object_transformer.object_mapper import CustomObjectMapper


class AutoPropertyMapper(object):

    def __init__(self, instance_to_register, args, with_JSON=None) -> None:
        super(AutoPropertyMapper, self).__init__()
        self.mapper = CustomObjectMapper(*args)
        self.register_mapper(instance_to_register, self.mapper)
        self.instance = instance_to_register
        if with_JSON is not None:
            self.mapper.from_json(with_JSON, instance_to_register)

    def register_mapper(self, instance_to_register, mapper):
        transformer.register(type(instance_to_register).__name__, mapper)

    def to_JSON(self):
        return self.mapper.to_json(self.instance)

    def assign_object_data(self, json_data):
        pass
