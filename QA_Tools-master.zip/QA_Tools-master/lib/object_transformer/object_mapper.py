class CustomObjectMapper(object):
    def __init__(self, *attrs, **json_attrs):
        self.attributes = set(attrs) | set(json_attrs)
        self.json_attrs = dict((attr, self.json_attr(attr)) for attr in attrs)
        self.json_attrs.update(json_attrs)

    def __call__(self, source):
        return self.to_json(source)

    def json_attr(self, attr):
        return attr

    def to_json(self, source):
        destination = {}
        for attr in self.attributes:
            if hasattr(source, attr):
                value = getattr(source, attr)
                if isinstance(value, list) or isinstance(value, tuple) or isinstance(value, set):
                    value = [item.to_JSON() if hasattr(item, "to_JSON") else item for item in value]
                if isinstance(value, dict):
                    value = dict((key, value[key].to_JSON) if hasattr(value[key], "to_JSON")
                                 else (key, value[key]) for key in value)

                dest_attr = self.json_attrs.get(attr, attr)
                if hasattr(value, "to_JSON"):
                    value = value.to_JSON()
                destination[dest_attr] = value

        return destination

    def from_json(self, source, destination):
        attributes = self.attributes
        for attr in attributes:
            source_attr = self.json_attrs.get(attr, attr)
            if source_attr in source:
                value = source[source_attr]
                setattr(destination, attr, value)

        return destination

    def pick(self, source):
        destination = {}

        attributes = self.attributes
        for attr in attributes:
            source_attr = self.json_attrs.get(attr, attr)
            if source_attr in source:
                value = source[source_attr]
                destination[attr] = value
        return destination


class CustomObjectCamelMapper(CustomObjectMapper):
    def json_attr(self, attr):
        cs = []
        upper = False
        for c in attr:
            if c == '_':
                upper = True
            elif upper:
                cs.append(c.upper())
                upper = False
            else:
                cs.append(c)
        return ''.join(cs)
