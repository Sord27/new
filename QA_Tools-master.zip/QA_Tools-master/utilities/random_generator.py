import random
import string


class RandomGenerateTools:
    def __init__(self):
        pass

    @staticmethod
    def generate_first_name():
        return RandomGenerateTools.generate_word()

    @staticmethod
    def generate_last_name():
        # step1: load last name list from data folder
        # step2: select a random last_name
        return RandomGenerateTools.generate_word()

    @staticmethod
    def generate_email(email_base="siq_automation", email_host="sleepnumber.com", randomize=True):
        """
        Generates email address in format: email_base + optional_random_string +  @ + email_domain
        :param email_base: This is the beginning of generated email address.
        :param email_host: ending of email
        :param randomize: Add random string between email_base and email_host
        :return:
        """
        random_ending = ''
        if randomize:
            random_ending += random.choice(['_', '.', ''])
        return email_base + random_ending + str(random.randint(900000, 99990000)) + '@' + email_host

    @staticmethod
    def generate_word(length=5):
        vowels = "aeiou"
        consonants = "".join(set(string.ascii_lowercase) - set(vowels))
        word = ""
        for i in range(length):
            if i % 2 == 0:
                word += random.choice(consonants)
            else:
                word += random.choice(vowels)
        return word

    # get random string password with letters, digits, and symbols
    @staticmethod
    def get_random_password_string(length):
        password_characters = string.ascii_letters + string.digits + string.punctuation
        password = 'RFv2' + ''.join(random.choice(password_characters) for i in range(length))
        return password
