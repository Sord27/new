import csv
import json
import os


class DataUtilities:
    def __init__(self):
        pass

    @staticmethod
    def read_json_from_file(path):
        with open(path) as json_file:
            return json.load(json_file)

    @staticmethod
    def read_csv_into_list_from_file(path):
        results= None
        # read csv file as a list of lists
        with open(path, 'r') as read_obj:
            # pass the file object to reader() to get the reader object
            csv_reader = csv.reader(read_obj)
            # Pass reader object to list() to get a list of lists
            results = list(csv_reader)
        return results

    @staticmethod
    def read_json_from_data_folder(path):
        try:    
            data_path = os.path.join(os.path.dirname(__file__), '../data' + path)
            return DataUtilities.read_json_from_file(data_path)
        except:
            raise Exception("Incorrect json format or file: "  + data_path)

    @staticmethod
    def read_text_from_data_folder(path):
        data_path = os.path.join(os.path.dirname(__file__), '../data' + path)
        with open(data_path, 'rb') as f:
            return f.read().decode("utf-8")

    @staticmethod
    def write_into_data_output_folder(file_name, text):
        DataUtilities.create_folder_if_not_exists(os.path.join(os.path.dirname(__file__), '../output'))
        with open(os.path.join(os.path.dirname(__file__), f'../data/output/{file_name}'), 'w') as filetowrite:
            filetowrite.write(text)

    @staticmethod
    def write_jarray_into_csv(file_name, jarray):
        DataUtilities.create_folder_if_not_exists(os.path.join(os.path.dirname(__file__), '../output'))
        data_file = open(os.path.join(os.path.dirname(__file__), f'../output/{file_name}.csv'), 'w')
        csv_writer = csv.writer(data_file)
        try:
            count = 0
            for element in jarray:
                if count == 0:
                    # Writing headers of CSV file
                    header = element.keys()
                    csv_writer.writerow(header)
                    count += 1

                # Writing data of CSV file
                csv_writer.writerow(element.values())
        finally:
            data_file.close()


    @staticmethod
    def create_folder_if_not_exists(folder):
        if not os.path.exists(folder):
            os.makedirs(folder)