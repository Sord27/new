from __future__ import annotations

from typing import List

from pydantic import BaseModel, typing


class User(BaseModel):
    accountOwner: bool
    emailValidated: bool
    accountId: str
    parentAccountId: typing.Any
    roles: List[str]
    reference: str
    active: bool
    userId: str
    login: str
    firstName: str
    lastName: str
    lastLogin: str
