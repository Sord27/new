BE_ADMIN = "https://test-admin-svc.test.siq.sleepnumber.com"
BE_APPS = "https://test-apps-svc.test.siq.sleepnumber.com"
FE_ADMIN = "https://test-admin-api.test.siq.sleepnumber.com"
FE_APPS = "https://test-api.test.siq.sleepnumber.com"
