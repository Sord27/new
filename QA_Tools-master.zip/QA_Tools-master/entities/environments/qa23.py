BE_ADMIN = "https://qa23-admin-svc.dev.siq.sleepnumber.com"
BE_APPS = "https://qa23-apps-svc.dev.siq.sleepnumber.com"
FE_ADMIN = "https://qa23-admin-api.dev.siq.sleepnumber.com"
FE_APPS = "https://qa23-api.dev.siq.sleepnumber.com"
