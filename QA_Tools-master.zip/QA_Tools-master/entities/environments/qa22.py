BE_ADMIN = "https://qa22-admin-svc.dev.siq.sleepnumber.com"
BE_APPS = "https://qa22-apps-svc.dev.siq.sleepnumber.com"
FE_ADMIN = "https://qa22-admin-api.dev.siq.sleepnumber.com"
FE_APPS = "https://qa22-api.dev.siq.sleepnumber.com"
