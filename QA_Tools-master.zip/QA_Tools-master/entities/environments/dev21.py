BE_ADMIN = "https://dev21-admin-svc.dev.siq.sleepnumber.com"
BE_APPS = "https://dev21-apps-svc.dev.siq.sleepnumber.com"
FE_ADMIN = "https://dev21-admin-api.dev.siq.sleepnumber.com"
FE_APPS = "https://dev21-api.dev.siq.sleepnumber.com"
