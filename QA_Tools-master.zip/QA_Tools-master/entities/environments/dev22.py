BE_ADMIN = "https://dev22-admin-svc.dev.siq.sleepnumber.com"
BE_APPS = "https://dev22-apps-svc.dev.siq.sleepnumber.com"
FE_ADMIN = "https://dev22-admin-api.dev.siq.sleepnumber.com"
FE_APPS = "https://dev22-api.dev.siq.sleepnumber.com"
