BE_ADMIN = "https://circle1-admin-svc.circle.siq.sleepnumber.com"
BE_APPS = "https://circle1-apps-svc.circle.siq.sleepnumber.com"
FE_ADMIN = "https://circle1-admin-api.circle.siq.sleepnumber.com"
FE_APPS = "https://circle1-api.circle.siq.sleepnumber.com"
