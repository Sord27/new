BE_ADMIN = "https://dev24-admin-svc.dev.siq.sleepnumber.com"
BE_APPS = "https://dev24-apps-svc.dev.siq.sleepnumber.com"
FE_ADMIN = "https://dev24-admin-api.dev.siq.sleepnumber.com"
FE_APPS = "https://dev24-api.dev.siq.sleepnumber.com"
