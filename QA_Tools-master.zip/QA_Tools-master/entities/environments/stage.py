BE_ADMIN = "https://stage-admin-svc.stage.siq.sleepnumber.com"
BE_APPS = "https://stage-apps-svc.stage.siq.sleepnumber.com"
FE_ADMIN = "https://stage-admin-api.stage.siq.sleepnumber.com"
FE_APPS = "https://stage-api.stage.siq.sleepnumber.com"
