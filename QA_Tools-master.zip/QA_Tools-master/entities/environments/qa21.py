BE_ADMIN = "https://qa21-admin-svc.dev.siq.sleepnumber.com"
BE_APPS = "https://qa21-apps-svc.dev.siq.sleepnumber.com"
FE_ADMIN = "https://qa21-admin-api.dev.siq.sleepnumber.com"
FE_APPS = "https://qa21-api.dev.siq.sleepnumber.com"
