from entities.environments import dev21, dev22, dev23, dev24, qa21, qa22, qa23, test, circle1, stage

environment_mapper = {
    'qa21': qa21,
    'qa22': qa22,
    'qa23': qa23,
    'dev21': dev21,
    'dev22': dev22,
    'dev23': dev23,
    'dev24': dev24,
    'test': test,
    'circle1': circle1,
    'stage': stage
}
