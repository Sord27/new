import json
import os
import random
from datetime import datetime
from termcolor import colored
from controllers.Account.be_account_controller import BeAccountController
from lib.client.be_admin_client import BeAdminClient
from lib.obra_session import OBRASession
from utilities.data_utilities import DataUtilities
import sys


class AccountCreator:

    def __init__(self):
        p = AccountCreator.account_create_executor()
        print(p)

    @staticmethod
    def account_create_executor(instruction_folder='account_creator_instructions.csv'):
        """
        Creates the accounts as instructed and outputs the accounts on output folder
        """
        result = "Unknown"
        try:
            print("Account creator started")
            print("Loading instructions")
            instructions = AccountCreator.get_instructions(instruction_folder)

            print("Instructions loaded")
            try:
                for instruction in instructions:
                    if "-test" in sys.argv:
                        instruction["login"] = "account_create_health_check_7834@sleepnumber.com"
                    AccountCreator.account_create(instruction)
            except Exception as ex:
                print(colored('Error ', 'red') + str(ex))
        except Exception as e:
            print(colored('Error on account_create_executor ', 'red') + str(e))
            result = result + "\n" + str(e)
        return result

    @staticmethod
    def get_instructions(instruction_folder):
        try:

            if instruction_folder.endswith(".csv"):
                users = DataUtilities.read_csv_into_list_from_file('account_creator_instructions.csv')
                instructions = []
                for user in users:
                    raw_name = user[0].split('@')
                    if "." in raw_name[0]:
                        fn = raw_name[0].split('.')[0]
                        ln = raw_name[0].split('.')[1]
                    else:
                        raise Exception("Naming format is not correct. please update the email. ex: firstname.lastname@sleepnumber.com")
                    instruction = {
                        "first_name": fn,
                        "last_name": ln,
                        "login": user[0],
                        "password": "SNb!" + str(random.randint(10000,90000)) + ln,
                        "roles":  user[1].replace(' ', '').split(','),
                        "environments": user[2].replace(' ', '').split(',')
                        }
                    instructions.append(instruction)
                return instructions
            else:
                return DataUtilities.read_json_from_file(os.path.join(os.path.dirname(__file__) + "/" + instruction_folder))
        except Exception as e:
            raise Exception(
                "Create account instruction is not inputed as expected please check account_creator_instructions.csv\ninfo: https://selectcomfort.atlassian.net/wiki/spaces/QA/pages/1502019608/Creating+Accounts+on+Multiple+Environments\n" + str(e))
    @staticmethod
    def account_create(instructions):
        """
        Creates the accounts as instructed and outputs the accounts on output folder
        """

        accounts = []
        try:

            environments = instructions['environments']
            for environment in environments:
                try:
                    if environment == "prod":
                        raise Exception("Creating an account is restricted to the Prod environment! " +
                                        "Please contact your supervisor to request for Prod access")

                    print(f"Creating {instructions['login']} in {environment}")
                    be_client = BeAdminClient(OBRASession(environment))
                    # be_client.set_proxy("10.0.0.244:8866")

                    if "-test" in sys.argv or "-delete" in sys.argv:
                        print(colored("Deleting account:", "yellow") + f" {instructions['login']}")
                        BeAccountController(be_client).delete_account(by_filter=instructions['login'], ignore_failure=True)
                        print(colored("Deleted:", "green") + f" {instructions['login']}")
                    if "-delete" in sys.argv:
                        continue
                    new_account = BeAccountController.create_account(
                        be_client, first_name=instructions['first_name'], last_name=instructions['last_name'],
                        login=instructions['login'], password=instructions['password'], roles=instructions['roles'])
                    accounts.append({
                        'Environment': environment,
                        'account_id': new_account.account_id,
                        'login': new_account.login,
                        'password:': new_account.password,
                        'result': 'Success!'
                    })
                except Exception as e:
                    accounts.append({
                        'Environment': environment,
                        'account_id': 'Null',
                        'login': 'Null',
                        'password:': 'Null',
                        'result': "Fail: " + str(e).replace(',', '')
                    })
                    print(colored('Can not create: ', 'red') + instructions['login'] + " in " + environment + " "+ str(e))

            result = "\n" + json.dumps(accounts, indent=4)
            print(result)
            output_file = instructions['first_name'] + "." + instructions['last_name'] + "." + datetime.now().strftime("%Y_%m_%d-%H_%M_%S")
            DataUtilities.write_jarray_into_csv(output_file, accounts)
        except Exception as e:
            print(colored('Error ', 'red') + str(e))
        return accounts


p = AccountCreator.account_create_executor()